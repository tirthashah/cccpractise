<?php
class Cart_Controller_index extends Core_Controller_Front_Action{
    
}
?>