<?php

class Customer_Controller_Quote_Address
{
    public function newAction()
    {
        echo "Address New Action";
    }
    public function listAction()
    {
        echo "Address New Action";
    }
    public function saveAction()
    {
        echo "Address New Action";
    }
    public function deleteAction()
    {
        echo "Address New Action";
    }

}