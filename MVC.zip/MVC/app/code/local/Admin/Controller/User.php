<?php

class Admin_Controller_User extends Core_Controller_Admin_Action
{
    protected $_allowedActions = array('login');

    protected $_username='abcabc@gmail.com';

    protected $_password= 'npmi';
    
    public function loginAction(){
        if(isset($_POST["submit"])){
            $data = $this->getRequest()->getParams("login");
            $model= Mage::getModel("customer/customer");
            // print_r($data);
            $result =   $model->getCollection()
            ->addFieldToFilter("customer_email", $data["customer_email"])
            ->addFieldToFilter("password", $data["password"]);
            $count=0;
            $customerId =0;
            foreach($result->getData() as $row){
                $count++;
                $customerId = $row->getCustomerId();
            }
            if($count){
                Mage::getSingleton("core/session")->set("logged_in_customer_id",$customerId);
                $this->setRedirect("customer/account/dashboard");
            }
            else{
                $this->setRedirect("customer/account/login");
                
            }
    
        }
        else{   
            $layout = $this->getLayout();
            $layout->removeChild('header')->removeChild('footer');
            $child = $layout->getChild('content');
            $layout->getChild('head')->addCss('header.css')
                                ->addCss('form.css');
            $login = $layout->createBlock('customer/login')->setTemplate('customer/account/login.phtml');
            $child->addChild('login', $login);
            $layout->toHtml();
        }
        }
}
