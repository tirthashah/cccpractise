<?php
class Admin_Block_Dashboard extends Core_Block_Template{
    public function __construct(){
        $this->setTemplate("customer/account/dashboard.phtml");
    }
}