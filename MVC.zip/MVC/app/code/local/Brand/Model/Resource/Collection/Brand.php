<?php
class Brand_Model_Resource_Collection_brand extends Core_Model_Resource_Collection_Abstract{
    
}
?>