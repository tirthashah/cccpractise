<?php
class Brand_Model_Resource_Brand extends Core_Model_Resource_Abstract{

    public function _construct(){
        $this->init("brand","brand_id");
    }
    
}

?>