<?php
class Brand_Block_List extends Core_Block_Template{
    public function __construct(){
        $this->setTemplate("brand/list.phtml");
    }
}
?>