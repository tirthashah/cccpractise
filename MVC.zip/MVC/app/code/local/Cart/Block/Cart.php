<?php

class Cart_Block_Cart extends Core_Block_Template{
    
}

?>