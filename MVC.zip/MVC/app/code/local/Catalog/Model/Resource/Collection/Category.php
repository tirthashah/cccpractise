<?php
class Catagory_Model_Resource_Collection_Category{

}
?>
<?php
