<?php
class Catalog_Block_Admin_Category_list  extends Core_Block_Template {
    public function __construct() { 
         $this->setTemplate("catalog/admin/category/list.phtml"); //design
    }

}
?>