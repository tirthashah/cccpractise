<?php
class Core_Model_Product{

}

?>
