<?php

class Core_Model_Session
{

}