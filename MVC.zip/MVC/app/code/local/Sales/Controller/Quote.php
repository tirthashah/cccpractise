<?php
class Sales_Controller_Quote extends Core_Controller_Front_Action{

    
     public function addAction() {
        $data =  $this->getRequest()->getParams('cart');
        $quote = Mage::getModel('sales/quote')->addProduct($data);
    }
    public function deleteAction() {
        //  $request =  $this->getRequest()->getQueryData('id');
         $request = ['quote_id' => $this->getRequest()->getParams('qid'),
                        'item_id' => $this->getRequest()->getParams('id')];
         $quote = Mage::getSingleton('sales/quote')->removeProduct($request);   
        }
}
