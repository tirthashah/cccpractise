<?php
class Calculator_Block_List extends Core_Block_Template{
    public function __construct(){
        $this->setTemplate("Calculator/list.phtml");
    }
}
?>