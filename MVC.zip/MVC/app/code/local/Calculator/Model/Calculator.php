<?php

class Calculator_Model_Calculator extends Core_Model_Abstract{
    
    public function init(){
        $this->_resourceClass = 'Calculator_Model_Resource_Calculator';
        $this->_collectionClass = 'Calculator_Model_Resource_Collection_Calculator';
    }
    public function _beforeSave(){
        $var1=$this->getFrontNumber();
       $var2= $this->getToNumber();
        $opr = $this->getOprator();

     switch ($opr) {
        case '+':
            $res=$var1+$var2;
        case '-':
            $res=$var1-$var2;
        case '*':
            $res=$var1*$var2;
        case '/':
            if($var2 != 0 ){
                 $res=$var1/$var2;
            }else{
                $res=0;
            }
        case '%':
            $res=$var1%$var2;
        
        default:
            # code...
            break;
     }

    }
}
?>
