<?php
 Class Banner_Controller_Index extends Core_Controller_Front_Action{
    
 }
?>