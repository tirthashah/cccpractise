<?php
class Banner_Model_Resource_Banner{
    
}
?>