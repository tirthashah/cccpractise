<?php

class Banner_Model_Banner
{
}