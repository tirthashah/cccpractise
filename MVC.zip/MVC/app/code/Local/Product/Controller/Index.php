<?php

class Product_Controller_Index{
    public function indexAction()
    {
        echo "Product_Controller";
    }
}