<?php
class Product_Controller_Index
{
    public function newAction()
    {
        echo "Product New Action";
    }
    public function listAction()
    {
        echo "Product List Action";
    }
    public function saveAction()
    {
        echo "Product Save Action";
    }
    public function deleteAction()
    {
        echo "Product Delete Action";
    }
}