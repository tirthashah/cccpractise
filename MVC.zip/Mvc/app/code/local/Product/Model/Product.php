<?php 

class Product_Model_Product extends Core_Model_Abstract
{

}

?>