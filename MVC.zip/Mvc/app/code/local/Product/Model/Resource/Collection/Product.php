<?php

class Product_Model_Resource_Collection_Product{
    
}

?>