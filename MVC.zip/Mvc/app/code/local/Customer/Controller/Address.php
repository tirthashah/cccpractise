<?php
class Customer_Controller_Address
{
    public function newAction()
    {
        echo "Address New Action";
    }
    public function listAction()
    {
        echo "Address List Action";
    }
    public function saveAction()
    {
        echo "Address Save Action";
    }
    public function deleteAction()
    {
        echo "Address Delete Action";
    }
}