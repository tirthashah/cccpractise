<?php
class Customer_Controller_Index
{
    public function newAction()
    {
        echo "Customer New Action";
    }
    public function listAction()
    {
        echo "Customer List Action";
    }
    public function saveAction()
    {
        echo "Customer Save Action";
    }
    public function deleteAction()
    {
        echo "Customer Delete Action";
    }
}