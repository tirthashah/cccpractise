<?php 
include_once("App/Mage.php");
include_once("App/Code/Local/autoload.php");
Mage ::init();
?>